package com.alonginfo.core.utils;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

/**
 * @Description: ..下载录入信息 所需要的格式 模板 excel
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 11:37
 */
public class FileDownload {
    public static String fileDownload(String fileName, HttpServletRequest request, HttpServletResponse response){
        // 设置响应头，以附件形式下载完成
        response.setHeader("context-type","application/octet-stream");
        response.setContentType("application/octet-stream");

        try {
            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode(fileName,"utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        byte[] buff = new byte[1024];
        BufferedInputStream bis = null;
        OutputStream out = null;
        try {
            // 获取文件所在地址 文件夹先写死，
            String downloadFile = request.getSession().getServletContext().getRealPath("downloadFile");
            File file = new File(downloadFile + "\\" + fileName);
            out = response.getOutputStream();
            bis = new BufferedInputStream(new FileInputStream(file));
            int i = bis.read(buff);
            while (i!=-1){
                out.write(buff,0,buff.length);
                out.flush();
                i = bis.read(buff);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (bis != null ){
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return "success";
    }
}
