package com.alonginfo.core.utils;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;


public class PoiUtil {
    /**
     *  poi导出
     * @param title 一级标题
     * @param titles 二级菜单
     * @param list 正文内容
     * @return
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    public  static HSSFWorkbook poiExcelExport(String title , List<String> titles, List list) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        // 1 创建一个excel的工作簿
        HSSFWorkbook workbook = new HSSFWorkbook();
        //2 创建一个工作空间
        HSSFSheet sheet = workbook.createSheet("sheet1");
        //3 合并单元格
        //参数1:从第几行合并  参数2:合并到多少行  参数3:从第几列合并 参数4:合并到多少列
        CellRangeAddress region = new CellRangeAddress(0,0,0,titles.size()-1);
        sheet.addMergedRegion(region);
        //4 创建表头
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell(0);
        //5 创建单元格样式对象
        HSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//居中对齐
        HSSFFont font = workbook.createFont();//创建字体
        font.setFontName("仿宋");
        font.setFontHeightInPoints((short)16);
        cellStyle.setFont(font);//设置字体
        cell.setCellStyle(cellStyle);
        cell.setCellValue(title);//设置文本内容

        HSSFCellStyle cellStyle2 = workbook.createCellStyle();
        cellStyle2.setAlignment(HorizontalAlignment.CENTER);//居中对齐
        HSSFFont font2 = workbook.createFont();//创建字体
        font2.setFontName("宋体");
        font2.setFontHeightInPoints((short)12);
        cellStyle2.setFont(font2);
        //6 创建几列  标题栏
        HSSFRow titleRow = sheet.createRow(1);
        for (int i = 0; i < titles.size(); i++) {
            String header = titles.get(i);
            HSSFCell titleCell = titleRow.createCell(i);
            titleCell.setCellStyle(cellStyle2);
            titleCell.setCellValue(header);
        }

        // 7 通过传入的数据集合 反射拿到对象中的数据，插入表格中
        for (int i =0;i<list.size();i++) {
            Class<?> aClass = list.get(i).getClass();
            Field[] declaredFields = aClass.getDeclaredFields();
            row = sheet.createRow(i + 2);
            for (int j = 0; j < declaredFields.length; j++) {
                Field declaredField = declaredFields[j];
                String name = declaredField.getName();
                String getMethod = "get" + name.substring(0, 1).toUpperCase() + name.substring(1);
                Object invoke = null;
                try {
                    Method method = aClass.getMethod(getMethod, new Class[]{});
                    invoke = method.invoke(list.get(i), new Object[]{});
                    row.createCell(j).setCellValue(invoke.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return workbook;
    }




}
