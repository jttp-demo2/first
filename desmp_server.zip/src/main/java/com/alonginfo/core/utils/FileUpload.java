package com.alonginfo.core.utils;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 11:07
 */
public class FileUpload {
}
