package com.alonginfo.core.config;

import com.alonginfo.core.security.SignInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author rayjp
 * @create 2018-12-13
 **/
@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(getSignInterceptor());
	}

	/**
	 * 添加拦截器
	 *
	 * @param registry
	 */
	@Bean
	public HandlerInterceptor getSignInterceptor() {
		return new SignInterceptor();
	}


}
