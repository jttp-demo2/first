package com.alonginfo.system.model;

import lombok.Data;

import java.util.Date;

/**
 *  运维模块 -- 维修记录 pojo
 */

@Data
public class Ywmaintain {
    private Integer mnId;

    private String mnYhmc;

    private String mnRegion;

    private String mnWxry;

    private String mnWxdata;

    private String mnPhone;

    private String mnWxjl;


}