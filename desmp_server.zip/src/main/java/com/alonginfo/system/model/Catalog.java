package com.alonginfo.system.model;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @Description: ..目录entity
 * @Author : Jp
 * @Date : 2019/1/7
 * @Time : 13:37
 */
@Data
public class Catalog {
    private Integer id;
    private String name;
    private String url;
    private String icon;
    private String type;
    private Integer sort;
    private Date creatDate;
    private Integer status;
    private Integer pid;
    private List<Catalog> cataList;

}
