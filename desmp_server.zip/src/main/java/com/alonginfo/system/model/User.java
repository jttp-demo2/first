package com.alonginfo.system.model;

import lombok.Data;

import java.util.Date;

/**
 * @author rayjp
 * @create 2018-12-12
 **/
@Data
public class User {

  private Integer id;
  private String name;
  private Integer age;
  private Date createDate;
}
