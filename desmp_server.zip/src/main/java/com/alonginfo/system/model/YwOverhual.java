package com.alonginfo.system.model;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 *   运维模块 --检修记录pojo
 */
@Data
public class YwOverhual {

    private Integer ohId;

    private String ohYhmc;

    private String ohRegion;

    private String ohJxdw;

    private String ohJxry;

    private String ohPhone;

    private String ohBegindata;

    private String ohEnddata;

    private String ohJxjl;

}