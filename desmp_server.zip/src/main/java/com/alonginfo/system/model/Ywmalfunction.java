package com.alonginfo.system.model;

import lombok.Data;


/**
 *  运维模块 -- 故障记录pojo
 */

@Data
public class Ywmalfunction {

    private Integer mfId;

    private String mfYhmc;

    private String mfRegion;

    private String mfJlry;

    private String mfJldata;

    private String mfPhone;

    private String mfGzjl;


}