package com.alonginfo.system.controller;

import com.alonginfo.core.utils.RedisUtil;
import com.alonginfo.system.model.User;
import com.alonginfo.system.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author rayjp
 * @create 2018-12-13
 **/
@Slf4j
@RestController
@RequestMapping("/system")
public class UserController {

	@Autowired
	private RedisUtil redisUtil;
	@Autowired
	private UserService userService;

	@PostMapping("/users")
	public int addUser(@RequestBody User user) {
		return userService.addUser(user);
	}

	@DeleteMapping("/users/{id}")
	public int deleteUser(@PathVariable int id) {
		return userService.deleteUser(id);
	}

	@GetMapping("/users")
	public List<User> queryUserList() {
		return userService.queryUserList();
	}

	@PutMapping("/users/{id}")
	public int updateUser(@PathVariable int id, @RequestBody User user) {
		user.setId(id);
		return userService.updateUser(user);
	}


}
