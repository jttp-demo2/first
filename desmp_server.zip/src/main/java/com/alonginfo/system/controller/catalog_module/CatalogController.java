package com.alonginfo.system.controller.catalog_module;

import com.alonginfo.system.model.Catalog;
import com.alonginfo.system.service.catalog_module.CatalogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description: 系统一二级目录 显示
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 10:21
 */
@Slf4j
@RestController
//@CrossOrigin(origins = {"http://127.0.0.1:9000", "null"})
public class CatalogController {

    @Resource
    private CatalogService catalogService;

    @GetMapping("catalogs")
    public List<Catalog> queryAllCatalog(){

       return  catalogService.queryAll();
   }
}
