package com.alonginfo.system.controller.yunwei_module;

import com.alonginfo.core.utils.PoiUtil;
import com.alonginfo.system.model.YwOverhual;
import com.alonginfo.system.service.yunwei_module.YwOverhualService;
import com.sun.deploy.net.HttpResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * @Description: ..运维模块 -检修
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 15:12
 */
@RestController
@Slf4j
public class YwOverhualController {
    @Resource
    private YwOverhualService ywOverhualService;

    @GetMapping("ywovehuals")
    public Map<String,Object> queryByPageNum(@RequestParam(value = "pageNum",defaultValue = "1") Integer pageNum,
                                             @RequestParam(value = "pageSize",defaultValue = "10") Integer pageSize,YwOverhual ywOverhual){
        Map<String, Object> objectMap = ywOverhualService.selectBySelective(ywOverhual, pageNum, pageSize);
        return objectMap;

    }

    @DeleteMapping("ywoverhuals/{id}")
    public int deleteByid(@PathVariable Integer id){
        return ywOverhualService.deleteByPrimaryKey(id);
    }

    @PostMapping("ywoverhuals")
    public int addYwOverhual(@RequestBody YwOverhual  ywOverhual){
        return ywOverhualService.insert(ywOverhual);
    }

    @PutMapping("ywoverhuals")
    public int  updateYwOverhual(@RequestBody YwOverhual ywOverhual){
        return ywOverhualService.updateByPrimaryKey(ywOverhual);
    }

    @GetMapping("ywoverhuals/export")
    public void export( @RequestParam("ids")List<Integer> ids ,HttpServletResponse response){
        ywOverhualService.excleExport(ids,response);
    }


}
