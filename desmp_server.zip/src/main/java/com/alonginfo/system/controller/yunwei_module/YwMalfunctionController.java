package com.alonginfo.system.controller.yunwei_module;

import com.alonginfo.system.model.Ywmalfunction;
import com.alonginfo.system.service.yunwei_module.YwMalfunctionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..运维模块 -故障
 * @Author : Jp
 * @Date : 2019/1/17
 * @Time : 11:31
 */
@Slf4j
@RestController
public class YwMalfunctionController {

    @Resource
    private YwMalfunctionService ywMalfunctionService;

    @GetMapping("ywmalfunctions")
    public Map<String,Object> queryByPageNum(@RequestParam(value = "pageNum",defaultValue = "1") Integer pageNum,
                                             @RequestParam(value = "pageSize",defaultValue = "10") Integer pageSize, Ywmalfunction ywmalfunction){
        Map<String, Object> objectMap = ywMalfunctionService.selectBySelective(ywmalfunction, pageNum, pageSize);
        return objectMap;

    }

    @DeleteMapping("ywmalfunctions/{id}")
    public int deleteById(@PathVariable Integer id){
        return ywMalfunctionService.deleteByPrimaryKey(id);
    }

    @PostMapping("ywmalfunctions")
    public int addYwOverhual(@RequestBody Ywmalfunction ywmalfunction){
        return ywMalfunctionService.insert(ywmalfunction);
    }

    @PutMapping("ywmalfunctions")
    public int  updateYwOverhual(@RequestBody Ywmalfunction ywmalfunction){
        return ywMalfunctionService.updateByPrimaryKey(ywmalfunction);
    }
    @GetMapping("ywmalfunctions/export")
    public void export(@RequestParam("ids") List<Integer> ids , HttpServletResponse response){
        ywMalfunctionService.excleExport(ids,response);
    }
}
