package com.alonginfo.system.controller.yunwei_module;

import com.alonginfo.system.model.Ywmaintain;
import com.alonginfo.system.service.yunwei_module.YwMaintainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description: .. 运维模块 -维修
 * @Author : Jp
 * @Date : 2019/1/17
 * @Time : 14:15
 */
@Slf4j
@RestController
public class YwMaintainController {
    @Resource
    private YwMaintainService ywMaintainService;

    @GetMapping("ywmaintains")
    public Map<String,Object> queryByPageNum(@RequestParam(value = "pageNum",defaultValue = "1") Integer pageNum,
                                             @RequestParam(value = "pageSize",defaultValue = "10") Integer pageSize, Ywmaintain ywmaintain){
        Map<String, Object> objectMap = ywMaintainService.selectBySelective(ywmaintain, pageNum, pageSize);
        return objectMap;

    }

    @DeleteMapping("ywmaintains/{id}")
    public int deleteById(@PathVariable Integer id){
        return ywMaintainService.deleteByPrimaryKey(id);
    }

    @PostMapping("ywmaintains")
    public int addYwOverhual(@RequestBody Ywmaintain ywmaintain){
        return ywMaintainService.insert(ywmaintain);
    }

    @PutMapping("ywmaintains")
    public int  updateYwOverhual(@RequestBody Ywmaintain ywmaintain){
        return ywMaintainService.updateByPrimaryKey(ywmaintain);
    }

    @GetMapping("ywmaintains/export")
    public void export(@RequestParam("ids") List<Integer> ids , HttpServletResponse response){
        ywMaintainService.excleExport(ids,response);
    }
}
