package com.alonginfo.system.service;

import com.alonginfo.system.mapper.UserMapper;
import com.alonginfo.system.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author rayjp
 * @create 2018-12-13
 **/
@Service
public class UserService {
  @Autowired
  private UserMapper userMapper;

  public List<User> queryUserList(){
    List<User> list = userMapper.queryUserList();
    return list;
  }

  public int addUser(User user){
    return userMapper.addUser(user);
  }

  public int updateUser(User user){
    return userMapper.updateUser(user);
  }

  public int deleteUser(int id){
    return userMapper.deleteUser(id);
  }
}
