package com.alonginfo.system.service.catalog_module;

import com.alonginfo.system.model.Catalog;

import java.util.List;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 10:12
 */
public interface CatalogService {

    List<Catalog> queryAll();
}
