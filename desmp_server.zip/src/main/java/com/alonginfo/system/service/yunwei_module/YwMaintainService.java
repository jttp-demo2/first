package com.alonginfo.system.service.yunwei_module;

import com.alonginfo.system.model.Ywmaintain;
import org.apache.ibatis.annotations.Param;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..运维模块 - 维修表
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 14:36
 */
public interface YwMaintainService {

    int deleteByPrimaryKey(Integer mnId); // 根据主键删除

    int insert(Ywmaintain record); // 插入记录 - 整条

    int updateByPrimaryKey(Ywmaintain record); // 整条修改
    //遍历查询 打包导出数据
    void excleExport(List<Integer> ids, HttpServletResponse response);
    //选择条件查询
    Map<String,Object> selectBySelective(Ywmaintain ywmaintain, Integer pageNum, Integer pageSize);

}
