package com.alonginfo.system.service.yunwei_module;

import com.alonginfo.system.model.YwOverhual;
import org.apache.ibatis.annotations.Param;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..运维模块 - 检修表
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 14:21
 */
public interface YwOverhualService {

    int deleteByPrimaryKey(Integer ohId); // 主键删除

    int insert(YwOverhual record); // 整条插入

    int updateByPrimaryKey(YwOverhual record); //整条修改

    //遍历查询 打包导出数据
    //List<YwOverhual> selectMany(List<Integer> ids);

    //选择条件查询
    Map<String,Object> selectBySelective(YwOverhual ywOverhual,Integer pageNum,Integer pageSize);

    // 数据表格导出
    void excleExport(List<Integer> ids, HttpServletResponse response);


}
