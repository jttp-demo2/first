package com.alonginfo.system.service.yunwei_module;

import com.alonginfo.core.utils.PoiUtil;
import com.alonginfo.system.mapper.yunwei_module.YwmaintainMapper;
import com.alonginfo.system.model.Ywmaintain;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 14:57
 */
@Service
@Transactional
public class YwMaintainImp implements YwMaintainService {

    @Resource
    private YwmaintainMapper ywmaintainMapper;
    @Value("#{'${wx-title}'}")
    private String title;
    @Value("#{'${wx-titles}'.split(',')}")
    private List<String> titles;

    @Override
    public int deleteByPrimaryKey(Integer mnId) {
        return ywmaintainMapper.deleteByPrimaryKey(mnId);
    }

    @Override
    public int insert(Ywmaintain record) {
       return ywmaintainMapper.insert(record);
    }

    @Override
    public int updateByPrimaryKey(Ywmaintain record) {
        return ywmaintainMapper.updateByPrimaryKey(record);
    }

    @Override
    public void excleExport(List<Integer> ids, HttpServletResponse response) {
        List<Ywmaintain> list = ywmaintainMapper.selectMany(ids);
        // 2 设置表名
        String fileName = "运维检修-电站维修记录表"+System.currentTimeMillis()+".xls";
        try {
            // 3 工具类 获取excel表格
            HSSFWorkbook workbook = PoiUtil.poiExcelExport(title, titles,list);
            //解决浏览器差异 标题中文乱码问题
            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode(fileName,"utf-8"));
            // 4 流下载
            OutputStream os = response.getOutputStream();
            workbook.write(os);
            os.flush();
            os.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public Map<String, Object> selectBySelective(Ywmaintain ywmaintain, Integer pageNum, Integer pageSize) {
        // 1 根据需求 传参 若有ywoverhual 则是条件查询 分頁显示；若对象空，则是分頁站是所有
        List<Ywmaintain> ywmaintains = ywmaintainMapper.selectBySelective(ywmaintain, pageNum, pageSize);
        // 2 将总行数 查出 存入map 返回给前端 使用
        int i = ywmaintainMapper.selectCount();
        Map<String, Object> map = new HashMap<String,Object>();
        map.put("list",ywmaintains); //分頁展示的list集合
        map.put("total",i); // 总行数
        return map;
    }
}
