package com.alonginfo.system.service.yunwei_module;

import com.alonginfo.system.model.YwOverhual;
import com.alonginfo.system.model.Ywmalfunction;
import org.apache.ibatis.annotations.Param;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..运维模块 -故障记录表
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 14:23
 */
public interface YwMalfunctionService {

    int deleteByPrimaryKey(Integer mfId); //根据主键删除

    int insert(Ywmalfunction record); // 插入整条

    int updateByPrimaryKey(Ywmalfunction record); // 整条修改

    //遍历查询 打包导出数据
    void excleExport(List<Integer> ids, HttpServletResponse response);
    //选择条件查询
    Map<String,Object> selectBySelective(Ywmalfunction ywmalfunction, Integer pageNum, Integer pageSize);

}
