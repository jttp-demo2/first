package com.alonginfo.system.service.catalog_module;

import com.alonginfo.system.mapper.catalog_module.CatalogMapper;
import com.alonginfo.system.model.Catalog;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 10:15
 */
@Service
public class CatalogServiceImp implements CatalogService {
    @Resource
    private CatalogMapper catalogMapper;

    @Override
    public List<Catalog> queryAll() {
        List<Catalog> catalogs = catalogMapper.queryAll();

        return catalogs;
    }
}
