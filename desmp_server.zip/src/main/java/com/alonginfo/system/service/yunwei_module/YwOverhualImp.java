package com.alonginfo.system.service.yunwei_module;

import com.alonginfo.core.utils.PoiUtil;
import com.alonginfo.system.mapper.yunwei_module.YwOverhualMapper;
import com.alonginfo.system.model.YwOverhual;
import com.alonginfo.system.service.yunwei_module.YwOverhualService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/16
 * @Time : 14:39
 */
@Service
@Transactional
public class YwOverhualImp implements YwOverhualService {
    @Resource
    private YwOverhualMapper ywOverhualMapper;
    @Value("#{'${jx-titles}'.split(',')}")
    private List<String> titles;    // 取配置文件中的 菜单内容
    @Value("#{'${jx-title}'}")
    private String title;

    @Override
    public int deleteByPrimaryKey(Integer ohId) {
        return ywOverhualMapper.deleteByPrimaryKey(ohId);
    }

    @Override
    public int insert(YwOverhual record) {
        return ywOverhualMapper.insert(record);
    }


    @Override
    public int updateByPrimaryKey(YwOverhual record) {
        return ywOverhualMapper.updateByPrimaryKey(record);
    }


    @Override  // 分頁 展示所有  提供搜索 分頁展示
    @Transactional(propagation = Propagation.SUPPORTS,readOnly = true)
    public Map<String, Object> selectBySelective(YwOverhual ywOverhual, Integer pageNum, Integer pageSize) {
       // 1 根据需求 传参 若有ywoverhual 则是条件查询 分頁显示；若对象空，则是分頁展示所有
        List<YwOverhual> ywOverhuals = ywOverhualMapper.selectBySelective(ywOverhual, pageNum, pageSize);
       // 2 将总行数 查出 存入map 返回给前端 使用
        int i = ywOverhualMapper.selectCountNum();
        Map<String, Object> map = new HashMap<String,Object>();
        map.put("list",ywOverhuals); //分頁展示的list集合
        map.put("total",i); // 总行数
        return map;
    }

    // poi 用户导出数据
    @Override
    public void excleExport(List<Integer> ids,HttpServletResponse response) {
        // 1 根据传入的ids 获得需要导出的数据
        List<YwOverhual> list = ywOverhualMapper.selectMany(ids);
        // 2 设置表名
        String fileName = "运维检修-电站检修记录表"+System.currentTimeMillis()+".xls";
        try {
            // 3 工具类 获取excel表格
            HSSFWorkbook workbook = PoiUtil.poiExcelExport(title, titles,list);
            //解决浏览器差异 标题中文乱码问题
            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode(fileName,"utf-8"));
            // 4 流下载
            OutputStream os = response.getOutputStream();
            workbook.write(os);
            os.flush();
            os.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}
