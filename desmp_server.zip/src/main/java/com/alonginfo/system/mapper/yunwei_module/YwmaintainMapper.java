package com.alonginfo.system.mapper.yunwei_module;


import com.alonginfo.system.model.Ywmaintain;
import com.alonginfo.system.model.Ywmalfunction;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *  运维 -- 维修 mapper
 */
public interface YwmaintainMapper {

    int deleteByPrimaryKey(Integer mnId); // 根据主键删除

    int insert(Ywmaintain record); // 插入记录 - 整条

    int updateByPrimaryKey(Ywmaintain record); // 整条修改
    //遍历查询 打包导出数据
    List<Ywmaintain> selectMany(@Param("ids") List<Integer> ids);
    //选择条件查询
    List<Ywmaintain> selectBySelective(@Param("ywmaintain") Ywmaintain ywmaintain,@Param("pageNum") Integer pageNum,@Param("pageSize") Integer pageSize);
    //总行数
    int selectCount();

}