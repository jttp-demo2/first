package com.alonginfo.system.mapper.catalog_module;

import com.alonginfo.system.mapper.Dao;
import com.alonginfo.system.model.Catalog;

import java.util.List;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/7
 * @Time : 13:39
 */
public interface CatalogMapper extends Dao<Catalog> {

}
