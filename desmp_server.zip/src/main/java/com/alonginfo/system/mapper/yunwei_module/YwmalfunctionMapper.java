package com.alonginfo.system.mapper.yunwei_module;

import com.alonginfo.system.model.Ywmalfunction;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *  运维 - 故障
 */
public interface YwmalfunctionMapper {

    int deleteByPrimaryKey(Integer mfId); //根据主键删除

    int insert(Ywmalfunction record); // 插入整条

    int updateByPrimaryKey(Ywmalfunction record); // 整条修改

    //遍历查询 打包导出数据
    List<Ywmalfunction> selectMany(@Param("ids")List<Integer> ids);
    //选择条件查询
    List<Ywmalfunction> selectBySelective(@Param("ywmalfunction") Ywmalfunction ywmalfunction,@Param("pageNum")Integer pageNum, @Param("pageSize")Integer pageSize);
    //总行数
    int selectCountNum();

}