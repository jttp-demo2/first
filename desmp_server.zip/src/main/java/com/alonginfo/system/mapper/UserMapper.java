package com.alonginfo.system.mapper;

import com.alonginfo.system.model.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author rayjp
 * @create 2018-12-13
 **/
@Mapper
public interface UserMapper {

  List<User> queryUserList();
  int addUser(User user);
  int updateUser(User user);
  int deleteUser(int id);
}
