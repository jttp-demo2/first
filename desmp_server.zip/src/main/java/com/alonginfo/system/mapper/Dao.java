package com.alonginfo.system.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface Dao<T> {
	// 登陆
	T login(@Param("account") String account, @Param("password") String password);
	// 查所有
	List<T> queryAll();
	// 查一个
	T queryOneById(int id);
	// 增加
	void insertOne(T t);
	// 删除
	void deleteById(int id);
	// 修改
	void  updateById(T t);
	//  假删除
	void  updateStatus(int id);
	// 分頁
	List<T> queryAllByPage(@Param("pageCount") int pageCount, @Param("pageSize") int pageSize);
	// 总条目数
	int getCountNum();
}
