package com.alonginfo.system.mapper.yunwei_module;

import com.alonginfo.system.model.YwOverhual;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 运维 -  检修
 */
public interface YwOverhualMapper {

    int deleteByPrimaryKey(Integer ohId); // 主键删除

    int insert(YwOverhual record); // 整条插入

    int updateByPrimaryKey(YwOverhual record); //整条修改

    //遍历查询 打包导出数据
    List<YwOverhual> selectMany(@Param("ids")List<Integer> ids);
    //选择条件查询 分页显示
    List<YwOverhual> selectBySelective(@Param("ywOverhual")YwOverhual ywOverhual,@Param("pageNum")Integer pageNum,@Param("pageSize")Integer pageSize);
    // 总行数
    int selectCountNum();
}