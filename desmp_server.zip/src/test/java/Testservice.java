
import com.alonginfo.DesmpApplication;
import com.alonginfo.system.model.Catalog;
import com.alonginfo.system.model.YwOverhual;
import com.alonginfo.system.service.catalog_module.CatalogService;
import com.alonginfo.system.service.yunwei_module.YwOverhualService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.*;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/8
 * @Time : 10:18
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DesmpApplication.class)
public class Testservice {

    @Autowired
    private CatalogService catalogService;
    @Resource
    private YwOverhualService ywOverhualService;

    @Test
    public void testCataservice(){
        List<Catalog> catalogs = catalogService.queryAll();
        for (Catalog catalog : catalogs) {
            System.out.println(catalog);
        }
    }

    @Test
    public void test1(){
        int i = ywOverhualService.deleteByPrimaryKey(10);
        System.out.println(i);
    }

    @Test
    public void test2(){
        YwOverhual ywOverhual = new YwOverhual();
       // ywOverhual.setOhYhmc("云");
       // ywOverhual.setOhBegindata("2019-1-14");
        Map<String, Object> objectMap = ywOverhualService.selectBySelective(ywOverhual, 2, 4);

        Iterator<Map.Entry<String, Object>> iterator = objectMap.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry<String, Object> next = iterator.next();
            System.out.println(next.getKey()+"  ----- "+next.getValue());
        }
    }

}
