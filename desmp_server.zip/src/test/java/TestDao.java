import com.alonginfo.DesmpApplication;
import com.alonginfo.system.mapper.*;
import com.alonginfo.system.mapper.catalog_module.CatalogMapper;
import com.alonginfo.system.mapper.yunwei_module.YwOverhualMapper;
import com.alonginfo.system.mapper.yunwei_module.YwmaintainMapper;
import com.alonginfo.system.mapper.yunwei_module.YwmalfunctionMapper;
import com.alonginfo.system.model.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description: ..
 * @Author : Jp
 * @Date : 2019/1/7
 * @Time : 17:49
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DesmpApplication.class)
public class TestDao {
    @Resource
    private CatalogMapper catalogMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private YwOverhualMapper ywOverhualMapper;
    @Resource
    private YwmaintainMapper ywmaintainMapper;
    @Resource
    private YwmalfunctionMapper ywmalfunctionMapper;




    @Test
    public void  testmal(){
        Ywmalfunction ywmalfunction = new Ywmalfunction();
        ywmalfunction.setMfYhmc("江");
        ywmalfunction.setMfJldata("2019-01-01");
        List<Ywmalfunction> ywmalfunctions = ywmalfunctionMapper.selectBySelective(ywmalfunction,1,2);
        for (Ywmalfunction ywmalfunction1 : ywmalfunctions) {
            System.out.println(ywmalfunction1);
        }
    }

    @Test
    public void testnum(){
        int i = ywmalfunctionMapper.selectCountNum();
        System.out.println(i);
    }

    @Test
    public void test3(){
        List list   = new ArrayList();
        list.add(1);
        list.add(2);
        List list1 = ywmalfunctionMapper.selectMany(list);
        for (Object o : list1) {
            System.out.println(o);
        }

    }


    @Test
    public void Testcatalog(){
        List<Catalog> catalogs = catalogMapper.queryAll();
        for (Catalog catalog : catalogs) {
            System.out.println(catalog);
        }
    }

    @Test
    public void testUser(){
        List<User> users = userMapper.queryUserList();
        System.out.println(users);
    }

    @Test
    public void testYwover() throws ParseException {
        YwOverhual yw = new YwOverhual();
        //yw.setOhId(2);
       // yw.setOhYhmc("云");
        yw.setOhJxjl("188");
       // yw.setOhBegindata("2019-01-14");
        yw.setOhJxry("一公司");

        System.out.println(yw);
        List<YwOverhual> ywOverhuals = ywOverhualMapper.selectBySelective(yw,1,5);
        for (YwOverhual ywOverhual : ywOverhuals) {
            System.out.println(ywOverhual);
        }
    }

    @Test
    public void testcount(){
        int i = ywOverhualMapper.selectCountNum();
        System.out.println(i);
    }

    @Test
    public void test4(){
       Ywmalfunction ywmalfunction = new Ywmalfunction();
        ywmalfunction.setMfYhmc("江苏丰海新能源工程技术有限公司");
        ywmalfunction.setMfRegion("330321");
        ywmalfunction.setMfJlry("赵欢");
        ywmalfunction.setMfJldata("2018-12-01 13:10:00");
        ywmalfunction.setMfPhone("19876542211");
        ywmalfunction.setMfGzjl("工厂内部微电网项目，施工会影响科技部863计划验收");
        int insert = ywmalfunctionMapper.insert(ywmalfunction);
        System.out.println(insert);

    }






    @Test
    public void testsel(){
        List list = new ArrayList();
        list.add(1);
        list.add(2);
        List list1 = ywmaintainMapper.selectMany(list);
        for (Object o : list1) {
            System.out.println(o);
        }
    }
    @Test
    public void testmany(){
        List list = new ArrayList();
        list.add(1);
        list.add(5);
        //list.add(2);
        List list1 = ywOverhualMapper.selectMany(list);
        for (Object o : list1) {
            System.out.println(o);
        }
    }


}


